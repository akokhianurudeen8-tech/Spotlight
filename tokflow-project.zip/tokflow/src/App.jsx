import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Home, Users, Compass, Radio, UserRound, Search, Plus, Heart, MessageCircle, Bookmark, Share2, Music2, Volume2, VolumeX, Play, Pause, X, Send, MoreHorizontal, Clapperboard, Flame, Check, LogIn } from 'lucide-react';

const initialVideos = [
  { id: 1, user: 'mila.moves', name: 'Mila Carter', avatar: 'https://i.pravatar.cc/120?img=47', video: 'https://videos.pexels.com/video-files/3129671/3129671-hd_1080_1920_25fps.mp4', caption: 'a little reminder to romanticize the ordinary ✨', tags: '#slowliving #dailyvlog #fyp', sound: 'original sound · mila', likes: 24800, comments: 382, color: '#bd7d72' },
  { id: 2, user: 'thecityframes', name: 'Jordan Lee', avatar: 'https://i.pravatar.cc/120?img=12', video: 'https://videos.pexels.com/video-files/854039/854039-hd_1920_1080_25fps.mp4', caption: 'POV: the city gives you a movie scene 🌆', tags: '#citylights #cinematic #travel', sound: 'Midnight City · M83', likes: 91400, comments: 1204, color: '#3d6e89' },
  { id: 3, user: 'kitchenwithkay', name: 'Kay Williams', avatar: 'https://i.pravatar.cc/120?img=44', video: 'https://videos.pexels.com/video-files/4253326/4253326-hd_1080_1920_25fps.mp4', caption: 'the 10-minute recipe I keep coming back to 🍜', tags: '#easyrecipes #foodtok #homecooking', sound: 'Sunday Kitchen · Kay', likes: 56300, comments: 876, color: '#8b7049' },
  { id: 4, user: 'wildlittleworld', name: 'Ari James', avatar: 'https://i.pravatar.cc/120?img=5', video: 'https://videos.pexels.com/video-files/856857/856857-hd_1920_1080_25fps.mp4', caption: 'take the scenic route. always. 🌿', tags: '#nature #outdoors #reset', sound: 'Bloom · The Paper Kites', likes: 187000, comments: 2411, color: '#46694e' },
];
const pretty = n => n >= 1e6 ? `${(n/1e6).toFixed(1).replace(/\.0$/,'')}M` : n >= 1e3 ? `${(n/1e3).toFixed(n >= 1e4 ? 1 : 1).replace(/\.0$/,'')}K` : String(n);

function App() {
  const [videos, setVideos] = useState(initialVideos);
  const [liked, setLiked] = useState({});
  const [saved, setSaved] = useState({});
  const [following, setFollowing] = useState({});
  const [active, setActive] = useState(1);
  const [muted, setMuted] = useState(true);
  const [playing, setPlaying] = useState({});
  const [commentsFor, setCommentsFor] = useState(null);
  const [commentText, setCommentText] = useState('');
  const [commentLists, setCommentLists] = useState({ 1: [{ user:'noah.jpg', text:'needed this today 🫶', likes:128 }, { user:'ellie', text:'the vibe is everything', likes:54 }], 2: [{ user:'samtravels', text:'this looks unreal 🔥', likes:81 }, { user:'mari', text:'where is this?', likes:23 }], 3: [{ user:'foodwithliz', text:'making this tonight!', likes:42 }], 4: [{ user:'river.s', text:'nature is the best therapy 🌱', likes:67 }] });
  const [tab, setTab] = useState('For You');
  const [query, setQuery] = useState('');
  const [toast, setToast] = useState('');
  const videoRefs = useRef({});
  const feedRef = useRef(null);
  const activeRef = useRef(1);

  const notify = useCallback((message) => { setToast(message); window.setTimeout(() => setToast(''), 2100); }, []);

  useEffect(() => {
    const nodes = document.querySelectorAll('[data-video-card]');
    const observer = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        const id = Number(entry.target.dataset.videoCard);
        const video = videoRefs.current[id];
        if (entry.isIntersecting && entry.intersectionRatio >= 0.65) {
          activeRef.current = id; setActive(id);
          if (video) { video.play().then(() => setPlaying(p => ({...p,[id]:true}))).catch(() => setPlaying(p => ({...p,[id]:false}))); }
        } else if (video) { video.pause(); setPlaying(p => ({...p,[id]:false})); }
      });
    }, { threshold: [0.25, 0.65, 0.9] });
    nodes.forEach(node => observer.observe(node));
    return () => observer.disconnect();
  }, [videos, tab, query]);

  useEffect(() => { Object.entries(videoRefs.current).forEach(([id, video]) => { if (video) video.muted = muted; }); }, [muted]);

  useEffect(() => {
    const onKey = e => {
      if (e.code !== 'Space' || ['INPUT','TEXTAREA'].includes(document.activeElement?.tagName)) return;
      e.preventDefault();
      const video = videoRefs.current[activeRef.current]; if (!video) return;
      if (video.paused) video.play().then(() => setPlaying(p => ({...p,[activeRef.current]:true}))).catch(()=>{});
      else video.pause();
    };
    window.addEventListener('keydown', onKey); return () => window.removeEventListener('keydown', onKey);
  }, []);

  const togglePlay = id => { const video = videoRefs.current[id]; if (!video) return; if (video.paused) video.play().then(() => setPlaying(p => ({...p,[id]:true}))).catch(()=>{}); else { video.pause(); setPlaying(p => ({...p,[id]:false})); } };
  const toggleLike = id => setLiked(p => ({...p, [id]: !p[id]}));
  const addComment = e => { e.preventDefault(); if (!commentText.trim() || !commentsFor) return; setCommentLists(p => ({...p,[commentsFor.id]: [...(p[commentsFor.id]||[]), { user:'you', text:commentText.trim(), likes:0 }]})); setCommentText(''); };
  const share = async video => { const url = `${window.location.origin}/?video=${video.id}`; try { if (navigator.share) await navigator.share({title:`@${video.user} on TokFlow`, text:video.caption, url}); else if (navigator.clipboard) { await navigator.clipboard.writeText(url); notify('Link copied to clipboard'); } else notify('Share this video with a friend'); } catch (e) { if (e.name !== 'AbortError') notify('Could not share right now'); } };
  const visibleVideos = videos.filter(v => `${v.user} ${v.caption} ${v.tags}`.toLowerCase().includes(query.toLowerCase()));
  const loadMore = () => setVideos(p => [...p, ...initialVideos.map((v,i) => ({...v, id: Math.max(...p.map(x=>x.id))+i+1, likes:v.likes+Math.floor(Math.random()*900), comments:v.comments+Math.floor(Math.random()*50)}))]);

  return <div className="app-shell">
    <header className="mobile-header"><button className="icon-button" onClick={() => setTab('Following')} aria-label="Following"><Users size={22}/></button><button className={`mobile-tab ${tab==='Following'?'selected':''}`} onClick={() => setTab('Following')}>Following</button><button className={`mobile-tab ${tab==='For You'?'selected':''}`} onClick={() => setTab('For You')}>For You</button><button className="icon-button" onClick={() => document.querySelector('.search-input')?.focus()} aria-label="Search"><Search size={22}/></button></header>
    <aside className="sidebar">
      <a className="brand" href="#top" aria-label="TokFlow home"><span className="brand-mark"><Clapperboard size={22}/></span><span>tok<span>flow</span></span></a>
      <label className="search-box"><Search size={18}/><input className="search-input" value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search creators" aria-label="Search creators"/>{query && <button onClick={()=>setQuery('')} aria-label="Clear search"><X size={14}/></button>}</label>
      <nav className="nav-list" aria-label="Main navigation">
        {[['For You',Home],['Following',Users],['EXPLORE',Compass],['LIVE',Radio],['Profile',UserRound]].map(([label,Icon])=><button key={label} className={`nav-link ${tab===label?'nav-active':''}`} onClick={()=>{setTab(label); if(label==='Profile') notify('Sign in to view your profile'); if(label==='LIVE') notify('Live streams are coming soon');}}><Icon size={22} strokeWidth={tab===label?2.5:1.8}/><span>{label}</span>{label==='LIVE'&&<i className="live-dot"/>}</button>)}
      </nav>
      <div className="sidebar-bottom"><p className="sidebar-note">Log in to follow creators, like videos, and view comments.</p><button className="login-button" onClick={()=>notify('Sign-in is a demo placeholder') }><LogIn size={18}/> Log in</button><button className="create-button" onClick={()=>notify('Video upload is coming soon')}><Plus size={19}/> Upload video</button><div className="sidebar-footer">© 2026 TokFlow · Demo experience</div></div>
    </aside>

    <main className="main-content" id="top">
      <div className="desktop-feed-header"><div><span className="eyebrow">YOUR DAILY DOSE OF VIDEO</span><h1>{tab==='Following'?'Following':tab==='EXPLORE'?'Explore creators':'For You'}</h1></div><div className="feed-tabs"><button className={tab==='Following'?'active':''} onClick={()=>setTab('Following')}>Following</button><span/><button className={tab!=='Following'?'active':''} onClick={()=>setTab('For You')}>For You</button></div></div>
      <div className="feed" ref={feedRef}>
        {visibleVideos.length ? visibleVideos.map((v,index)=><article className="video-card" data-video-card={v.id} key={v.id}>
          <video ref={el=>{videoRefs.current[v.id]=el;}} className="video-player" src={v.video} loop muted={muted} playsInline preload={index===0?'auto':'metadata'} onClick={()=>togglePlay(v.id)} onPlay={()=>setPlaying(p=>({...p,[v.id]:true}))} onPause={()=>setPlaying(p=>({...p,[v.id]:false}))} aria-label={`Video by ${v.user}`} />
          <div className="video-shade"/>
          <button className={`play-indicator ${playing[v.id]?'hidden':''}`} onClick={()=>togglePlay(v.id)} aria-label="Play video"><Play size={30} fill="white"/></button>
          <div className="video-topline"><span className="feed-label"><Flame size={14} fill="currentColor"/> TRENDING NOW</span><button className="sound-toggle" onClick={()=>setMuted(m=>!m)} aria-label={muted?'Unmute videos':'Mute videos'}>{muted?<VolumeX size={18}/>:<Volume2 size={18}/>}</button></div>
          <div className="video-info"><div className="creator-line"><button className="creator-name" onClick={()=>notify(`Viewing @${v.user}`)}>@{v.user}</button><span className="verified"><Check size={10}/></span><span className="video-dot">·</span><button className="follow-inline" onClick={()=>setFollowing(p=>({...p,[v.id]:!p[v.id]}))}>{following[v.id]?'Following':'Follow'}</button></div><p className="caption">{v.caption}</p><p className="hashtags">{v.tags}</p><div className="sound-line"><Music2 size={14}/><div className="sound-marquee">{v.sound}</div></div></div>
          <div className="action-rail"><div className="avatar-action"><button className="avatar-wrap" onClick={()=>notify(`Creator: @${v.user}`)}><img src={v.avatar} alt={`${v.name} avatar`}/></button><button className={`follow-plus ${following[v.id]?'is-following':''}`} onClick={()=>setFollowing(p=>({...p,[v.id]:!p[v.id]}))}>{following[v.id]?<Check size={13}/>:<Plus size={14}/>}</button></div>
            <button className={`rail-action like-action ${liked[v.id]?'is-liked':''}`} onClick={()=>toggleLike(v.id)} aria-label={liked[v.id]?'Unlike video':'Like video'}><span className="action-circle"><Heart size={25} fill={liked[v.id]?'currentColor':'none'}/></span><span>{pretty(v.likes+(liked[v.id]?1:0))}</span></button>
            <button className="rail-action" onClick={()=>setCommentsFor(v)} aria-label="View comments"><span className="action-circle"><MessageCircle size={24}/></span><span>{pretty((commentLists[v.id]?.length||v.comments))}</span></button>
            <button className={`rail-action ${saved[v.id]?'is-saved':''}`} onClick={()=>{setSaved(p=>({...p,[v.id]:!p[v.id]}));notify(saved[v.id]?'Removed from saved':'Added to saved');}} aria-label={saved[v.id]?'Remove bookmark':'Save video'}><span className="action-circle"><Bookmark size={23} fill={saved[v.id]?'currentColor':'none'}/></span><span>{saved[v.id]?'Saved':'Save'}</span></button>
            <button className="rail-action" onClick={()=>share(v)} aria-label="Share video"><span className="action-circle"><Share2 size={22}/></span><span>Share</span></button>
            <button className="album-disc" onClick={()=>setMuted(m=>!m)} aria-label="Toggle video sound"><img src={v.avatar} alt="Audio artwork"/><span><Music2 size={12}/></span></button>
          </div>
        </article>):<div className="empty-state"><Search size={28}/><h2>No videos found</h2><p>Try another creator name or hashtag.</p><button onClick={()=>setQuery('')}>Clear search</button></div>}
        {visibleVideos.length>0&&<button className="load-more" onClick={loadMore}><Plus size={16}/> Load more videos</button>}
      </div>
      <button className="global-mute" onClick={()=>setMuted(m=>!m)} aria-label={muted?'Unmute all videos':'Mute all videos'}>{muted?<VolumeX size={19}/>:<Volume2 size={19}/>}<span>{muted?'Sound off':'Sound on'}</span></button>
    </main>

    <nav className="mobile-bottom-nav"><button className={tab==='For You'?'selected':''} onClick={()=>setTab('For You')}><Home size={21}/><span>Home</span></button><button onClick={()=>setTab('EXPLORE')}><Compass size={21}/><span>Discover</span></button><button className="mobile-create" onClick={()=>notify('Video upload is coming soon')}><span><Plus size={23}/></span></button><button onClick={()=>setTab('Following')}><Users size={21}/><span>Following</span></button><button onClick={()=>notify('Sign in to view your profile')}><UserRound size={21}/><span>Profile</span></button></nav>

    {commentsFor&&<div className="drawer-backdrop" onClick={()=>setCommentsFor(null)}><section className="comments-drawer" onClick={e=>e.stopPropagation()} role="dialog" aria-modal="true" aria-label="Comments"><div className="drawer-handle"/><div className="drawer-header"><div><h2>Comments <span>{pretty(commentLists[commentsFor.id]?.length||commentsFor.comments)}</span></h2><p>Join the conversation</p></div><button className="icon-button" onClick={()=>setCommentsFor(null)} aria-label="Close comments"><X size={22}/></button></div><div className="comments-list">{(commentLists[commentsFor.id]||[]).map((c,i)=><div className="comment-item" key={`${c.user}-${i}`}><div className="comment-avatar">{c.user.slice(0,1).toUpperCase()}</div><div className="comment-body"><span className="comment-user">@{c.user}</span><p>{c.text}</p><span className="comment-time">Just now · Reply</span></div><button className="comment-like" onClick={e=>{e.currentTarget.classList.toggle('liked');}} aria-label="Like comment"><Heart size={15}/><span>{c.likes}</span></button></div>)}{!(commentLists[commentsFor.id]||[]).length&&<div className="no-comments"><MessageCircle size={30}/><p>Be the first to share your thoughts.</p></div>}</div><form className="comment-form" onSubmit={addComment}><div className="comment-input-wrap"><input value={commentText} onChange={e=>setCommentText(e.target.value)} placeholder="Add a comment…" aria-label="Write a comment"/><button type="submit" disabled={!commentText.trim()} aria-label="Post comment"><Send size={19}/></button></div><span className="comment-hint">Be kind. Keep it positive.</span></form></section></div>}
    {toast&&<div className="toast" role="status"><span className="toast-dot"/>{toast}</div>}
  </div>;
}

export default App;
